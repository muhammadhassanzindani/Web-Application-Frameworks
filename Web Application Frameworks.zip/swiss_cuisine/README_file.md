# Restaurant App

## Overview

This project is a web application that includes a frontend and a backend. The frontend is responsible for the user interface and interactions, while the backend handles the server-side logic and database operations. Follow the steps below to set up and run the project locally.

## Table of Contents

- [Frontend Setup](#frontend-setup)
- [Backend Setup](#backend-setup)
- [Technologies Used](#technologies-used)

## Frontend Setup

### Prerequisites

- Node.js (v18.x or later)
- npm (v10.x or later)

### Installation

1. **Clone the repository:**
   ```sh
   git clone https://github.com/yourusername/yourproject.git
   cd frontend

2. **Install the dependencies:**
    npm install
3. **Run the development server:**
    npm run dev

### The frontend should now be running at `http://localhost:5173`

## Backend Setup    
    cd backend
4. **Install the dependencies:**
    npm install
5. **Run the development server:**
    npm run dev

### The backend should now be running at `http://localhost:3001`


## Technologies Used
    **Frontend:** React, HTML, CSS, JavaScript
    **Backend:** Node.js, Express


    
