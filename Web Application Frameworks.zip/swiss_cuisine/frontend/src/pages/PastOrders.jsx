import axios from "axios";
import { useEffect, useState } from "react";
import { BASEURL } from "../utils";
import EachPastItem from "../Components/EachPastItem";


const PastOrders = () => {
    const [pastOrders, setPastOrders] = useState([]);

    useEffect(()=>{
        axios.get(`${BASEURL}/past-order`).then(res => {
            console.log(res.data, " ===oderData:all");
            setPastOrders(res.data);
        }).catch(err => {
            console.log(err.data, " ===oderData:all:err");
        });
    }, []);

    const handleRemove = (id) => {
        const orders = pastOrders.filter(order => order.orderId !== id);
        setPastOrders(orders);
    }

    return (
        <div className="container">
            {pastOrders.length !== 0 && 
                <div class="heading-container">
                    <h1 className="fw-bold text-center my-3 my-heading" style={{ fontFamily: 'Poppins', }}>Past Orders</h1>
                </div>
            }
            {pastOrders.length === 0 ? <p className='text-center fw-semibold fs-5'>No Past Order Found</p>  
            : 
            pastOrders.map(order => (<EachPastItem key={order.orderId} order={order} handleRemove={handleRemove} />))
            }
        </div>
    );
}


export default PastOrders;