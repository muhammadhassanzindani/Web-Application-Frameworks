import React, { useContext, useState } from 'react';
import data from '../utils/DATA.json';
import burger1 from '../assets/burger1.jpg';
import cheesePizza from '../assets/cheese_pizza.jpg';
import pizza1 from '../assets/pizza1.jpg';
import broast1 from '../assets/broast1.jpg';
import { OrderContext } from '../Context/OrderContext';
import CartItem from '../Components/CartItem';
import SubtotalCard from '../Components/SubTotalCard';
import { Col, Row } from 'react-bootstrap';
import axios from 'axios';
import { BASEURL } from '../utils';
import toastMessage from '../utils/toastMessage';

// Map the images
const imageMap = {
  "burger1.jpg": burger1,
  "cheese_pizza.jpg": cheesePizza,
  "pizza1.jpg": pizza1,
  "broast1.jpg": broast1,
};

const Cart = () => {
  const [loading, setLoading] = useState(false);
    const { orders, clearCart,  } = useContext(OrderContext);
    const addedIds = orders.map(order => order.id);
    const totalPrice = orders.reduce((total, order) => {
      return total + order.quantity * order.price
    }, 0);
    // console.log(totalPrice, "===totalPrice")
    
    const handleOrderSubmit = () => {
      setLoading(true);
      axios.post(`${BASEURL}/order`, { data: orders, totalPrice: parseFloat(totalPrice.toFixed(2) || 0), }).then(res => {
        console.log(res.data, "===order:submit");
        toastMessage("Order Confirmed", "success");
        clearCart();
      }).catch(err => {
        console.log(err, "===err:order:submit");
        toastMessage("Can't Order right now, please try later", "error")
      }).finally(()=>{
        setLoading(false);
      });
    }

  return (
    <div className="p-5">
      {orders.length === 0 ? <p className='text-center fw-semibold fs-5'>No Item Added</p> 
        : 
        <Row>
            <Col md={8}>
                {orders?.map(order => (
                    <CartItem key={order.id} item={order} addedIds={addedIds} isLoading={loading} />
                ))}
            </Col>
            <Col md={4}>
                <SubtotalCard totalPrice={totalPrice} onSubmit={handleOrderSubmit} isLoading={loading} />
            </Col>
        </Row>
      }
    </div>
  );
}

export default Cart;
