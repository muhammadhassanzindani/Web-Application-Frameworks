import data from '../utils/DATA.json';
import burger1 from '../assets/burger1.jpg';
import cheese_pizza from '../assets/cheese_pizza.jpg';
import pizza1 from '../assets/pizza1.jpg';
import broast1 from '../assets/broast1.jpg';
import { OrderContext } from '../Context/OrderContext';
import { useContext, useEffect, useState } from 'react';
import { Container, Row, Col, Card, Button, OverlayTrigger, Tooltip, } from 'react-bootstrap';
import axios from 'axios';
import { BASEURL, tagClass } from '../utils';




const Dashboard = () => {
    const { orders = [], addItem } = useContext(OrderContext);
    const addedIds = orders.map(order => order.id);
    const [products, setProducts] = useState([]);

    useEffect(()=>{
        axios.get(`${BASEURL}/products`).then(res => {
            console.log(res.data, "==res.dataaa");
            setProducts(res.data);
        })
    }, []);

    const handleAddCart = (orderItem) => {
        console.log(orderItem, "==orderItem");
        const newOrder = { ...orderItem, quantity: 1 };
        delete newOrder["description"];
        // delete newOrder["tags"];
        addItem(newOrder);
    }

    return (
        <>
            <div class="heading-container">
                <h1 className="fw-bold text-center my-3 my-heading" style={{ fontFamily: 'Poppins' }}>Swiss Cuisine</h1>
            </div>
            <Container>
                <Row className="justify-content-center">
                    {products.map(item => (
                        <Col key={item.id} md={6} lg={4} className="mb-4">
                            <Card className="text-center bg-white p-2 h-100 shadow-sm">
                                <Card.Img variant="top" src={`${BASEURL}/upload/${item.image}`} alt={item.name} style={{ width: '100%', height: '300px', objectFit: 'cover' }} />  {/* imageMap[item.image] */}
                                <Card.Body className='p-0 mt-3'>
                                    <div className={`d-flex justify-content-between`}>
                                        <div className="d-flex gap-1">
                                            {item.tags?.map(tag => <Card.Text key={tag}
                                                className={`${tagClass[tag]} text-white mb-0 d-flex justify-content-center align-items-center`} 
                                                style={{ fontSize: '11px', borderRadius: '4px', padding: '3px 7px' }}
                                                >
                                                    {tag}
                                                </Card.Text>)}
                                        </div>
                                        <Card.Text className='mb-0 bg-light fw-bold' style={{ fontSize: '14px', borderRadius: '4px', padding: '3px 7px' }}>${item.price}</Card.Text>
                                    </div>
                                    <div className="d-flex justify-content-between mt-3 mb-2">
                                        <Card.Title className="text-dark mb-0 text-uppercase" style={{ fontSize: '24px' }}>
                                            {item.name}
                                        </Card.Title>
                                        <OverlayTrigger
                                            placement="top"
                                            delay={{ show: 250, hide: 400 }}
                                            overlay={<Tooltip id="button-tooltip">{addedIds.includes(item.id) ? "Already added to Cart" : "Add to Cart"}</Tooltip>}
                                        >
                                            <button onClick={() => handleAddCart(item)} className={`px-2 fw-bold ${addedIds.includes(item.id) ? "custom-button-disabled" : "custom-button"}`}
                                                disabled={addedIds.includes(item.id)}
                                            >
                                                +
                                            </button>
                                        </OverlayTrigger>
                                    </div>
                                    <Card.Text className='text-start' style={{ fontSize: '14px', }}>{item.description}</Card.Text>
                                </Card.Body>
                            </Card>
                        </Col>
                    ))}
                </Row>
            </Container>
        </>
    );
}

export default Dashboard;

// Subhan allah hil azeem e wabi hamdihi wala hawla wala quawata illa billah