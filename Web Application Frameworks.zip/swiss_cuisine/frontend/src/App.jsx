import {
  createBrowserRouter,
  RouterProvider,
} from "react-router-dom";
import './App.css'
import Layout from "./Components/Layout";
import Dashboard from "./pages/Dashboard";
import Cart from "./pages/Cart";
import PastOrders from "./pages/PastOrders";
import { OrderProvider } from "./Context/OrderContext";

const router = createBrowserRouter([
    { path: '/', element: <Layout><Dashboard /></Layout> },
    { path: '/cart', element: <Layout><Cart /></Layout> },
    { path: '/past-orders', element: <Layout><PastOrders /></Layout> },
]);

function App() {
  return (
    <RouterProvider router={router} />
  );
}

export default App
