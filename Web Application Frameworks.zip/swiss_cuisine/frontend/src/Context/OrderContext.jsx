import { createContext, useEffect, useState } from 'react';

export const OrderContext = createContext();

export const OrderProvider = ({ children }) => {
  const [orders, setOrders] = useState([]);

  useEffect(()=>{
    if(localStorage){
      const cart = localStorage.getItem("cart") || "[]";
      if(cart){
        const cartDataParse = JSON.parse(cart);
        setOrders(cartDataParse);
      }
    }
  }, [])

  const addItem = (newOrderItem) => {
    let isExist = false;
    console.log(newOrderItem, 'newOrderItem');

    const updatedOrders = orders.map(item => {
        console.log(item.id === newOrderItem.id, "=item.id === newOrderItem.id");
        if(item.id === newOrderItem.id){
            isExist = true;
            return { ...item, quantity: item.quantity + 1 };
        }
        return item;
    }) 
    if(!isExist){
      setOrders([ ...updatedOrders, newOrderItem]);
      localStorage.setItem("cart", JSON.stringify([ ...updatedOrders, newOrderItem]));
    }
    else {
      setOrders(updatedOrders);
      localStorage.setItem("cart", JSON.stringify(updatedOrders));
    }
  };

  const handleQuantityChange = (id, newValue) => {
    const updatedOrders = orders.map(item => {
      // console.log(item.id === newOrderItem.id, "=item.id === newOrderItem.id");
      if(item.id === id){
        return { ...item, quantity: newValue };
      }
      return item;
    });

    localStorage.setItem("cart", JSON.stringify(updatedOrders));
    setOrders(updatedOrders);
  }
  
  const handleRemoveCart = (id) => {
    const updatedOrders = orders.filter(item => {
      if(item.id === id){
        return false;
      }
      return true;
    });
    
    localStorage.setItem("cart", JSON.stringify(updatedOrders));
    setOrders(updatedOrders);
  }

  const clearCart = () => {
    setOrders([]);
    localStorage.setItem("cart", JSON.stringify([]));
  }

  return (
    <OrderContext.Provider value={{ orders, addItem, handleQuantityChange, handleRemoveCart, clearCart, }}>
      {children}
    </OrderContext.Provider>
  );
};

export default OrderProvider;