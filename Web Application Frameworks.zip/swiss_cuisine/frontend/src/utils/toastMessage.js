import { Bounce, toast } from 'react-toastify';

const toastConfig = {
  position: "top-right",
  pauseOnHover: true,
  theme: "light",
  transition: Bounce,
  autoClose: 2000,
}

const toastMessage = (message, type) => {
  if(type === 'info'){
    toast.info(message, toastConfig);
  }
  else if(type === 'success'){
    toast.success(message, toastConfig);
  }
  else if(type === 'error'){
    toast.error(message, toastConfig);
  }
}

export default toastMessage;