
export const BASEURL = 'http://localhost:3001';

export const tagClass = {
    "New": "bg-success",
    "Hot": "bg-dark",
    "Spicy": "bg-danger",
    "Extra Sauce": "bg-primary",
    "Vegetarian": "bg-myorange",
    "Cheesy": "bg-my-pinkish-red",
    "Sweet": "bg-sweet",
    "Refreshing": "bg-refreshing",
    "Hearty": "bg-hearty",
}