import React, { useContext } from 'react';
import { Card } from 'react-bootstrap';
import { OrderContext } from '../Context/OrderContext';
import loadingIcon from '../assets/loading-icon.gif';

const SubtotalCard = ({ totalPrice=0, onSubmit=()=>{}, isLoading=false }) => {
    const { deliveryFee=0, gst=0 } = useContext(OrderContext);  // Assuming these values are managed in context

    const subtotal = totalPrice;
    const totalGST = subtotal * (gst / 100);
    const finalTotal = subtotal + totalGST + deliveryFee;


    return (
        <>
            <Card className="shadow-sm rounded">
                <Card.Body>
                    <Card.Title style={{ fontSize: '26px' }}>Summary</Card.Title>
                    <Card.Text className='d-flex justify-content-between'><span>Subtotal:</span> <span>${subtotal.toFixed(2)}</span></Card.Text>
                    <Card.Text className='d-flex justify-content-between'><span>GST (0%):</span> <span>${totalGST.toFixed(2)}</span></Card.Text>
                    <Card.Text className='d-flex justify-content-between'><span>Delivery:</span> <span>${deliveryFee.toFixed(2)}</span></Card.Text>
                    <Card.Text className="fw-bold d-flex justify-content-between"><span>Total:</span> <span>${finalTotal.toFixed(2)}</span></Card.Text>
                </Card.Body>
            </Card>
            <button onClick={onSubmit} className='custom-button w-100 mt-2 py-2' style={{ borderRadius: '5px', fontSize: '20px' }}>
                <span className='me-3'>
                    Order Now 
                </span>
                {isLoading &&
                    <span style={{ display: 'inline-block' }} className="spin-animation">
                        <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" id="loading" style={{ fill: 'white' }}>
                            <path d="M27.02 22.82a.182.182 1080 1 0 .364 0 .182.182 1080 1 0-.364 0zm-4.018 4.146a.362.362 1080 1 0 .724 0 .362.362 1080 1 0-.724 0zM17.586 29.1a.544.544 1080 1 0 1.088 0 .544.544 1080 1 0-1.088 0zm-5.83-.286a.724.724 1080 1 0 1.448 0 .724.724 1080 1 0-1.448 0zM6.584 26.16a.906.906 1080 1 0 1.812 0 .906.906 1080 1 0-1.812 0zm-3.582-4.512a1.088 1.088 1080 1 0 2.176 0 1.088 1.088 1080 1 0-2.176 0zm-1.344-5.54a1.268 1.268 1080 1 0 2.536 0 1.268 1.268 1080 1 0-2.536 0zm1.106-5.504a1.45 1.45 1080 1 0 2.9 0 1.45 1.45 1080 1 0-2.9 0zm3.318-4.438a1.632 1.632 1080 1 0 3.264 0 1.632 1.632 1080 1 0-3.264 0zm4.872-2.542a1.812 1.812 1080 1 0 3.624 0 1.812 1.812 1080 1 0-3.624 0zm5.472-.158a1.994 1.994 1080 1 0 3.988 0 1.994 1.994 1080 1 0-3.988 0zm5.01 2.254a2.174 2.174 1080 1 0 4.348 0 2.174 2.174 1080 1 0-4.348 0zm3.56 4.234a2.356 2.356 1080 1 0 4.712 0 2.356 2.356 1080 1 0-4.712 0zm1.416 5.484a2.538 2.538 1080 1 0 5.076 0 2.538 2.538 1080 1 0-5.076 0z"></path>
                        </svg>
                    </span>
                }
            </button>
        </>
    );
};

export default SubtotalCard;
