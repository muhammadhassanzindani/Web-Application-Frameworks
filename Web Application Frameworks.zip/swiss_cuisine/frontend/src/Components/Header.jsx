import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Navbar, Nav } from "react-bootstrap";
import icon from '../assets/burger_icon-fit.png';

const Header = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const [selectedPage, setSelectedPage] = useState("/");

    const handleMenuChange = (name) => {
        setSelectedPage(name);
        navigate(name);
    }

    useEffect(() => {
        setSelectedPage(location.pathname);
    }, [location.pathname]);

    return (
        <Navbar bg="dark" variant="underline" fixed="top" className="justify-content-between px-4">
            <div className="d-flex justify-content-center align-items-center gap-2">
                <img src={icon} alt="Icon" width={50} />
                <p className="text-white mb-0 fw-semibold" style={{ lineHeight: 1.3, marginTop: '4px', fontFamily: 'Poppins', textTransform: 'uppercase', }}>Swiss <br /> Cuisine</p>
            </div>
            <Nav className="gap-4">
                <Nav.Link
                    className={`text-xl font-semibold cursor-pointer py-1 ${selectedPage === "/" ? "bg-warning rounded px-2 fw-semibold" : "text-white"}`}
                    onClick={() => handleMenuChange("/")}
                >
                    Home
                </Nav.Link>
                <Nav.Link
                    className={`text-xl font-semibold cursor-pointer py-1 ${selectedPage === "/cart" ? "bg-warning rounded px-2 fw-semibold" : "text-white"}`}
                    onClick={() => handleMenuChange("/cart")}
                >
                    Cart
                </Nav.Link>
                <Nav.Link
                    className={`text-xl font-semibold cursor-pointer py-1 ${selectedPage === "/past-orders" ? "bg-warning rounded px-2 fw-semibold" : "text-white"}`}
                    onClick={() => handleMenuChange("/past-orders")}
                >
                    Past Orders
                </Nav.Link>
            </Nav>
        </Navbar>
    );
}

export default Header;
