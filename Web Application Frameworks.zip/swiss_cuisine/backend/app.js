const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
const { generateRandomNumber } = require("./utils");

const app = express();
const PORT = 3001;
const DATA_FILE = path.join(__dirname, "products.json");
const ORDER_FILE = path.join(__dirname, "orders.json");
const UPLOAD_DIR = path.join(__dirname, "upload");

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
// app.use("/upload", express.static(UPLOAD_DIR));
if (!fs.existsSync(UPLOAD_DIR)) {
    fs.mkdirSync(UPLOAD_DIR);
}

// Route to get all products
app.get("/products", (req, res) => {
    fs.readFile(DATA_FILE, (err, data) => {
        if (err) {
            return res.status(500).json({ error: "Failed to read data" });
        }
        const products = JSON.parse(data);
        res.json(products);
    });
});

// Route to get an image by its name
app.get("/upload/:imageName", (req, res) => {
    const imageName = req.params.imageName;
    const imagePath = path.join(UPLOAD_DIR, imageName);

    fs.access(imagePath, fs.constants.F_OK, (err) => {
        if (err) {
            return res.status(404).json({ error: "File not found" });
        }
        res.sendFile(imagePath);
    });
});

// Route to add a new order
app.post("/order", (req, res) => {
    const { data: newOrder, totalPrice } = req.body;
    // const orderId = generateRandomNumber();
    // console.log(newOrder);
    fs.readFile(ORDER_FILE, (err, data) => {
        if (err) {
            return res.status(500).json({ error: "Failed to read data" });
        }
        let orders = [];
        try {
            orders = JSON.parse(data);
        } catch (e) {
            orders = [];
        }
        orders.push({ data: newOrder, orderId: (orders.length || 0) + 1, totalPrice, });
        fs.writeFile(ORDER_FILE, JSON.stringify(orders, null, 2), (err) => {
            if (err) {
                return res.status(500).json({ error: "Failed to write data" });
            }
            res.status(201).json(newOrder);
        });
    });
});

app.get("/past-order", (req, res) => {
    fs.readFile(ORDER_FILE, (err, data) => {
        if (err) {
            return res.status(500).json({ error: "Failed to read data" });
        }
        const orderData = JSON.parse(data);
        res.json(orderData);
    });
});

// Route to delete a product by ID
app.delete("/order/:id", (req, res) => {
    const productId = parseInt(req.params.id);
    console.log(productId, " === prodId, ", typeof productId);
    fs.readFile(ORDER_FILE, (err, data) => {
        if (err) {
            return res.status(500).json({ error: "Failed to read data" });
        }
        let orders = JSON.parse(data);
        orders = orders.filter(order => order.orderId != productId);
        fs.writeFile(ORDER_FILE, JSON.stringify(orders, null, 2), (err) => {
            if (err) {
                return res.status(500).json({ error: "Failed to write data" });
            }
            res.status(200).send({ success: true, message: "Successfully Deleted" });
        });
    });
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
