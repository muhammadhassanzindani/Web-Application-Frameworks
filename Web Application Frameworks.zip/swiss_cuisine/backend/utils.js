function generateRandomNumber(){
    return Math.ceil(Math.random() * 1000000 + 1000000) + 
        "-" + Math.ceil(Math.random() * 10000000 + 10000000) +
        "-" + Math.ceil(Math.random() * 10000000 + 10000000) +
        "-" + Math.ceil(Math.random() * 8000000 + 8000000);
}


module.exports = { generateRandomNumber }